# BATM 3.0.0 — Repair Plan & executed changes (Fase 4 / 8 / 12)

Scope chosen conservatively: the runtime core (analysis, sanitizer, reducer, backup,
rollback, workers) is covered by the green offline suite and was intentionally left
functionally untouched. Two low-risk, behaviour-preserving repairs were executed.

## Executed changes

### 1. UI consolidation — `ui/panels.py` (Fase 8)

- Split the old `_draw_diagnostics` into:
  - `_draw_recovery(layout, context)` — always-visible **Attention Needed** safety
    block (recoverable backups → Restore / Discard, recent errors). Drawn in every state.
  - `_draw_technical(layout, context)` — the diagnostics metrics / exports / refresh,
    now presented as a collapsible **Technical Details** section.
  - `_draw_settings(layout, context)` — the **Settings** section that groups
    **Manual & Dictionary** (AutoTag rules), **Sanitizer** (Cleanup Rules) and
    **Technical Details**.
- Restructured `BATM_PT_main.draw` to the strict Fase 8 hierarchy:

```
METRICS     (collapsible, just above RUN)
RUN BATM    (dominant, scale_y=3, never collapsible)
TAG EDITOR  (Manual Tag Editor, collapsible)
SETTINGS    (Manual & Dictionary / Sanitizer / Technical Details)
RECOVERY    (safety block, only when backups or errors exist)
```

- All visible labels remain professional English; no operator/property identifiers
  were renamed, so no downstream references break.

### 2. Cosmetic runtime cleanup — `engine/metatags.py` (Fase 12)

- Replaced a stray `?` in a docstring with `—`. No behaviour change.

## Root-cause reasoning for ANALYSIS (Fase 1 objective)

The task asked specifically why ANALYSIS might be failing on Blender 5.2. Static
tracing of the path `BATM_OT_run.execute -> _hash_modal -> _start_analysis ->
BatchScheduler -> worker/batm_worker.py -> process_assets -> modal merge ->
_finish_analysis -> build_autotag_operations -> SESSION.compile` found the pipeline
internally complete and the previously-documented `status_path` crash already fixed.
No new root-cause defect was provable without executing Blender; the documented
finding is that runtime validation is required to claim ANALYSIS is working, and that
validation is recorded as pending (see verification.md).

## Not executed (deliberately)

- No functional edits to `core/`, `engine/autotag|sanitizer|segmenter|backup|reducer`,
  `worker/`, `operators/run.py`, `adapters/blender_assets.py` — all covered by the
  green offline suite and/or requiring Blender to validate.
- No removal of tests, tools, docs, or CI.
