# BATM 3.0.0 — Findings (Fase 1 / 2 / 5 / 11)

Method: full source read of every runtime module, `compileall` over the package,
JSON validation of `resources/*.json`, the offline suite (`python tests/_run_all.py`)
and targeted searches for debug/dead code. **Blender 5.2 was not available in the
environment**, so runtime/registration behavior was NOT executed (see verification.md).

## What was verified to be sound

1. **Syntax / imports / compile** — every module in `adapters/ core/ engine/
   operators/ ui/ worker/ tools/` and `__init__.py` compiles with `compileall`
   (exit 0). `__init__.py` imports resolve to modules that exist.
2. **Offline suite** — 17/17 green: add_exclusion, autotag_pipeline, backup,
   extractors_contract, false_success, fingerprint, ipc, knowledge, logging,
   reconcile, rules_hierarchy, sanitizer, scheduler, segmenter, stage_pipeline,
   steps_recombine, taxonomy.
3. **Resources** — `autotag_knowledge.json`, `autotag_rules.json`,
   `compound_splits.json`, `taxonomy.json` all parse as valid JSON.
4. **Analysis plumbing (static)** — `worker/batm_worker.py::analyze_files` includes
   `status_path` in the per-file sub-request consumed by `process_assets`. The
   previously documented `KeyError: 'status_path'` analysis crash is **fixed in the
   current code**; the CHANGELOG/SSOT description matches the actual code.
5. **Registration contract** — `register()` resets session state (`SESSION.reset()`),
   registers `CLASSES`, wires the `WindowManager.batm_runtime` pointer, loads rules,
   warns about recoverable backups and starts the inventory timer; `unregister()`
   cancels schedulers, unregisters the timer and reverses registration. Ordering and
   reverse ordering are consistent.
6. **Identity safety** — `find_local_id`/worker `find_id` prefer the non-linked
   datablock (`library is None`), so a homonymous linked asset is not edited.
7. **Rollback completeness** — `_begin_rollback` restores `completed + failed`, not
   only `completed`; the RESTORE worker is guarded by tag comparison.
8. **Sanitizer** — `apron`/`annette`/`fireforce` are preserved; only full exact-lexicon
   decompositions split; no invented Levenshtein boundaries remain.

## Issues found and addressed in this audit

| # | Severity | Issue | Action |
|---|---|---|---|
| 1 | Low (UI) | `_draw_diagnostics` lived OUTSIDE Settings; Technical Details competed with the main flow. | Moved Technical Details INTO Settings (Manual & Dictionary / Sanitizer / Technical Details). See repair_plan. |
| 2 | Cosmetic | `engine/metatags.py` docstring stray `?`. | Replaced with `—`. |
| 3 | Test flake | `tests/test_backup.py` ordering assertion depended on Windows `st_mtime` resolution: two backups created back-to-back could share mtime and order ambiguously, failing `newest is last`. | Enforced a real 50 ms time separation between the two backup creations so the ordering semantic is tested deterministically (production `recoverable_backups` left unchanged; suite now 17/17 green across repeated runs). |
| 4 | **Blocker (run aborts)** | `BATM_OT_run.modal` aborted with **"Analysis interrupted" on every run**. Root cause: when deferred fingerprinting is active (`_hashing`), `SESSION.scheduler` is intentionally `None` until `_start_analysis()` runs after hashing completes. But the `scheduler is None` abort check was reached on **any non-TIMER event** — incl. the very first click that triggered the operator — so it aborted immediately before analysis even started. | Guarded the abort with `not self._hashing` in `operators/run.py::modal`, so the scheduler is only required once hashing finished. Traced all paths (hashing/no-hashing/current-file/scheduler-loss) — correct. Compiles; offline suite still 17/17. |

## Observations (no action required, documented for transparency)

- **Metrics** box currently reports library-level metrics (active library, asset count,
  selection, catalog) rather than the full run-metric set enumerated in Fase 8 (tags
  found, unique tags, changes pending, elapsed, throughput). The collapse behaviour
  and placement directly above RUN BATM are satisfied; richer run-metrics were not
  added to avoid inventing transient state that cannot be runtime-validated here.
- **Blender runtime** (registration, Asset Browser context, worker execution, apply,
  rollback, refresh) could not be executed in this environment.

## Deliberately NOT touched

- No functional change to the analysis / sanitizer / reducer / backup / rollback core
  (they are covered by the green offline suite; changing them without Blender would
  risk regressions).
- No tests, tools, docs or CI removed. `audit/` was added but is build-excluded.

## 2026-08 independent release re-audit (packaging phase)

A fresh, independent full-source re-audit of the *current tree* (not trusting earlier
audits) reproduced the healthy core and found the release packaging was **stale and
incomplete** ("steps left half-done"):

| # | Severity | Issue (verified in the tree) | Action |
|---|---|---|---|
| 1 | **Blocker (release)** | `dist/BATM_V3-0-0.zip` was built from an OLDER snapshot: it shipped pre-fix sizes for `core/models.py` (5425 vs 5802 current), `core/reducer.py` (7139 vs 8506) and `ui/properties.py` (15581 vs 16939) — i.e. the `verbatim` verbatim-edit support, `CANCEL_ADD`, and the Review step toggles were absent from the packaged release. | Rebuilt the ZIP from the current source as `dist/BATM_3.0.0_Blender_5.2.zip`; archived the stale zip to `dist/archive/`. |
| 2 | **Packaging leak** | `tools/build_zip.py` and the manifest `paths_exclude_pattern` did not exclude `api_out.txt` / `api_err.txt` (transient output of `tools/_verify_blender_api.py`); a rebuild would ship them. | Added both to `EXCLUDE_ROOT_FILES` (build_zip.py) and to `blender_manifest.toml [build] paths_exclude_pattern`. |
| 3 | Dead import | `tools/build_zip.py` imported `shutil` but never used it. | Removed the import. |
| 4 | Artifact name | Build tool always emitted `batch_asset_tag_manager.zip`; the professional, version-coherent name is `BATM_3.0.0_Blender_5.2.zip`. | `build_zip.artifact_stem()` derives `BATM_{version}_Blender_{maj.min}` from the manifest; CI workflow attaches `dist/BATM_*.zip`. |

Re-verification of the rebuilt ZIP (PowerShell listing): 48 files, mindful exclusion of
`tests/ docs/ audit/ tools/ .git/ .github/ .batm_test/ dist/ __pycache__/` and the
root investigation files, manifest at ZIP root, every runtime module present and
matched byte-for-byte to the current disk tree, no leaks. The runtime code itself was
re-read in full and found coherent (analysis pipeline, reducer, AutoTag, segmenter,
backup/rollback, UI/registration). Real-Blender execution remains the only unverifiable
dimension in this environment.
