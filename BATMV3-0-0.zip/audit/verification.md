# BATM 3.0.0 — Verification (Fase 10 / 16)

## Verified in this environment

| Check | Result |
|---|---|
| Python syntax (compileall over runtime + tools) | PASS (exit 0) |
| JSON resources (4 files) | PASS (valid JSON) |
| Offline test suite (`tests/_run_all.py`) | PASS 17 / FAIL 0 (repeated runs) |
| UI refactor (`ui/panels.py`) compiles | PASS |
| Version SSOT: `__init__.py` + `blender_manifest.toml` = 3.0.0 | PASS |
| Blender 5.2 API surface used by BATM (against official docs) | PASS — all present (see below) |
| Production ZIP generated + contents inspected | PASS (48 files, no leaks) |

## Blender 5.2 API verification (Fase 1 / 3)

Verified against the official 5.2 API reference that every asset/Asset-Browser
attribute/operator BATM relies on exists:

- `bpy.ops.asset.library_refresh()` — present
- `AssetRepresentation`: `full_library_path`, `id_type`, `is_online`,
  `owner_asset_library`, `local_id`, `name` — all present
- `FileAssetSelectParams`: `asset_library_reference`, `asset_catalog_visibility` — present
- `AssetLibraryReference.name` — present
- `AssetMetaData.tags` — present

Re-verification helper: `tools/_verify_blender_api.py` (dev-only; excluded from ZIP).

## Analysis recovery (root cause)

`BATM_OT_run` aborted with **"Analysis interrupted"** on every run: while deferred
fingerprinting (`_hashing`) is active, `SESSION.scheduler` is intentionally `None`
until `_start_analysis()` runs after hashing completes; the modal's `scheduler is
None` abort check fired on the first non-TIMER event (the click that started the
operator). Fixed by guarding the abort with `not self._hashing`
(`operators/run.py::modal`). Traced every path (hashing / no-hashing /
current-file-only / scheduler-loss) — correct. Offline suite still 17/17.

## Not verified (environment limitation)

**Blender 5.2 was not available in this environment** (no `blender.exe` found on any
drive, not in the registry, no bundled Python on PATH). Therefore the following were
**NOT executed** and must not be claimed:

- Add-on registration / unregistration in Blender.
- Panel drawing (BATM sidebar appearance, RUN BATM dominance, Settings grouping).
- Asset Browser `context.selected_assets` / library-reference reading in a live session.
- REAL headless worker: INVENTORY, ANALYZE, APPLY, RESTORE, save_as_mainfile.
- End-to-end: select → Run → Review → Confirm → Apply → Verify → Rollback.
- `bpy.ops.asset.library_refresh()` after a run.

These are recorded as **pending real-Blender validation** (use
`tools/investigate_asset_browser.py` and `tools/_verify_blender_api.py` inside Blender 5.2).

## Honest status summary

- The code base is internally consistent, compiles, JSON-valid and 17/17 offline-green.
- Every documented Blender 5.2 API used by BATM is confirmed present.
- The "Analysis interrupted" blocker is fixed at the root cause.
- **Real Blender 5.2 runtime behaviour: NOT VERIFIED IN BLENDER.**

## Release packaging re-verification (2026-08)

Independent re-audit of the current tree (source of truth; prior audits not trusted).
Confirms the runtime code is internally coherent (reads/imports/registration/UI wiring
cross-checked) and that the release was **stale/incomplete** until repaired this session:

| Check | Result |
|---|---|
| Version SSOT (`BATM_VERSION` + manifest) | PASS — both 3.0.0 |
| Manifest parses; `paths_exclude_pattern` aligned with builder (+ `api_out.txt`/`api_err.txt`) | PASS |
| Build tool (`tools/build_zip.py`) emits professional name `BATM_3.0.0_Blender_5.2.zip`, excludes root investigation files, drops unused import | PASS |
| CI workflow attaches `dist/BATM_*.zip` | PASS |
| Production ZIP rebuilt from current source & inspected | **PASS — 48 files, no leaks, manifest at root, all modules present and byte-identical to disk** |
| Stale pre-fix `BATM_V3-0-0.zip` archived (removed from release staging) | PASS |

Still **NOT executed** in this environment (no `blender.exe`, no Python on PATH):
registration/unregistration, panel draw, Asset Browser selection, headless workers,
end-to-end run. These remain pending real-Blender validation
(`tools/investigate_asset_browser.py`, `tools/_verify_blender_api.py` inside Blender 5.2).

## AutoTag + pagination repair verification (2026-08, round 2)

User-reported defects repaired at root-cause level and verified with a **real
Python runtime** (`C:\Program Files\Python314`, discovered this session — the
pure-Python suite is now executable in this environment):

| Defect | Root cause | Fix | Verification |
|---|---|---|---|
| Animals tagged "Human" | (1) glued compounds (`foxcub`) hide fauna evidence from exact-token catalog matching, so contextual age terms fell back to their human default; (2) Human domain label injected whenever any human-domain word (`character`, `hero`, `beast`...) matched, even with fauna present | `engine/taxonomy.py`: decompose glued candidates with the prudent segmenter (cached per-taxonomy lexicon); suppress the whole Human domain when fauna matched | `test_taxonomy.py` new cases PASS; live sim: `fox+character` → `['Fauna','Mammal']`, `foxcub+child` → pup/Fauna, `child` alone still → human |
| Split Compound Words ignored `mat_foxcub_eyecornea` | (1) sanitizer segment branch required `base.isalnum()` — any `_`/`-`/space token skipped; (2) lexicon lacked `mat`, `eye`, `cornea` and `collect_words` ignored `contextual_terms` (`cub`) | `core/sanitizer.py`: per-sub-token decomposition (part expanded only when a sub-token truly splits — `fire_force` → "Fire Force" contract preserved; self-mapping fixups never count as splits); `engine/segmenter.py`: base words + contextual keys added to the lexicon | `test_segmenter.py` new cases PASS; live sim: `mat_foxcub_eyecornea` → `Mat, Fox, Cub, Eye, Cornea` (+ `Fox Cub`, `Eye Cornea` in Both mode) |
| Manual Tag Editor / Final Tags preview navigation | prev/next only, no first/last, no 10/100 switch; Final Tags capped at 80; pagination & Select All ignored the length filter | First/prev/next/last + 10/100 page size in Manual Tag Editor; Final Tags preview now filtered + paginated; shared `core/session.filter_tag_list` / `filtered_final_tags` as single source of truth | Static cross-check: 44 UI operator refs ⊆ 45 registered idnames; all new props defined/registered/used |

Full offline suite: **PASS = 17, FAIL = 0** (`tests/_run_all.py`, Python 3.14.3).
`compileall` over all runtime modules: clean. Production ZIP rebuilt via
`tools/build_zip.py` → `dist/BATM_3.0.0_Blender_5.2.zip` (48 files, no leaks,
manifest at root, changed files byte-identical to disk).

Still pending real-Blender validation (no `blender.exe` in this environment):
panel draw of the new navigation rows, double-click editing, live worker run.

