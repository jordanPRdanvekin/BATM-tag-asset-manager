# BATM 3.0.0 — Architecture

This document is part of the Fase 0–17 recovery audit of `batch_asset_tag_manager`.
It is development knowledge only and is **excluded** from the production ZIP.

## Identity

- Add-on id: `batch_asset_tag_manager`
- Product version: **3.0.0** (single source: `__init__.py` `BATM_VERSION = (3, 0, 0)`;
  `blender_manifest.toml` `version = "3.0.0"` is the packaging mirror).
- Distribution: Blender 4.2+ **extension** (`blender_manifest.toml`, installed under
  `extensions/`). There is intentionally **no `bl_info`** — the manifest is the packaging
  source, and `bl_info` is not used for extensions.
- Blender target: **5.2 LTS** (`blender_version_min = "5.2.0"`).

## Package layout (runtime)

```
__init__.py            Entry point: register() / unregister(), version SSOT.
adapters/              bpy + OS adapters (Blender assets, storage, worker IPC, stores).
  blender_assets.py    Asset Browser selection, snapshot, current-file read/write.
  storage.py           Atomic JSON storage; BATM base/backups/logs/runs/rules dirs.
  worker_ipc.py        Versioned JSON IPC + worker command construction.
  rule_store.py        Bundled-default vs user rule persistence.
  taxonomy_store.py    Bundled catalog + persisted user overrides.
core/                  Pure-Python domain (bpy-free, offline-testable).
  models.py            AssetKey / AssetSnapshot / TagOperation / DesiredAssetState / Rule.
  session.py           SessionController (in-memory state) + filtered_review_states().
  reducer.py           compile_states(): operations -> exact desired tag sets.
  sanitizer.py         Deterministic tag parsing / cleaning / normalization.
  rules.py             Declarative rule schema validation + load.
  fields.py            SSOT of rule match fields.
  state_machine.py     Strict BATM run-state transitions.
engine/                Processing engines (bpy-free where possible).
  inventory.py         AssetIndex + async inventory timer.
  autotag.py           AutoTag: enrich -> base -> metatags -> knowledge -> taxonomy -> rules.
  metatags.py          Objective structural facts (id_type, Contains*).
  knowledge.py         Bundled knowledge dictionary loading + matching.
  taxonomy.py          Concept catalog matching + user override merge.
  segmenter.py         Prudent compound-word segmentation.
  backup.py            Checksummed, verified Tag backup manifests.
  fingerprint.py       sha256/mtime/size file fingerprints.
  scheduler.py         Non-blocking batch subprocess scheduler + watchdog.
  logging.py           Persistent run logs + centralized diagnostics (never raises).
  diagnostics.py       Pure dataset diagnostics summary.
operators/             bpy.types.Operator subclasses (run, manual, rules, taxonomy, diagnostics).
ui/                    Panels, runtime/pref properties, Review drawing.
worker/batm_worker.py  Static headless Blender worker (INVENTORY / ANALYZE / APPLY / RESTORE).
docs/                  User docs (AUTOTAG_RULES, GRAPHS, KNOWLEDGE).
resources/             JSON: autotag_knowledge, autotag_rules, compound_splits, taxonomy.
tests/                 Offline, bpy-free test-suite (development only).
tools/                 build_zip.py + investigate_asset_browser.py (development only).
.github/workflows/     release.yml -> builds the ZIP on tag push (development only).
```

## Main flow (as implemented)

```
ASSET DISCOVERY   selected_assets(context) via Asset Browser -> AssetRepresentation
  -> READ         snapshot_selection(): AssetKey + tags + facts (local extract for
                  Current File; empty for external files)
  -> ANALYZE      BATMRuntime modal -> fingerprint deferred -> BatchScheduler ->
                  headless workers open each .blend and return {key, tags, facts}
  -> AUTOTAG      build_autotag_operations(): base + metatags + knowledge + taxonomy + rules
  -> SANITIZE     reducer.compile_states() + sanitizer (casing, separators, dedup, 63 cap, ...)
  -> APPROVAL     REVIEW_READY; editable Review (Add / Remove / Cleanup / Last Step);
                  per-asset enable; Confirm & Apply
  -> BACKUP       create_backup() checksummed manifest (verified before proceed)
  -> APPLY        worker APPLY opens file, verifies fingerprints, writes tags, saves,
                  re-opens and verifies each asset
  -> VERIFY       post-save re-read in the worker (tag_names == desired_tags)
  -> ROLLBACK     automatic on failure/cancel: RESTORE workers for every started job;
                  current-file path restored + saved + verified
```

## Isolation rules that hold in the code

- No Tag is written before REVIEW_READY → APPROVED → BACKED_UP → EXECUTING.
- Every file is written by exactly one worker (files are grouped per .blend).
- Fingerprints are checked before ANALYZE merge (worker) and before APPLY / ROLLBACK.
- All background work is subprocess-based; `bpy` is touched only on the main thread.
- Session state is in-memory only (`core.session.SESSION`), never stored in Scene data.
- `register()` resets transient state; `unregister()` cancels any active scheduler.

## Versioning sources

| Source | Value |
|---|---|
| `__init__.py` BATM_VERSION | `(3, 0, 0)` |
| `blender_manifest.toml` version | `3.0.0` |
| `README.md` | BATM v3.0.0 · Blender 5.2+ |
| `CHANGELOG.md` | `## v3.0.0 (current)` |
| Release artifact | `BATM_3.0.0_Blender_5.2.zip` |

## v3.0.0 Review ergonomics additions

- Review → Add step: double-click (or pencil) a proposed Tag to rewrite it on every
  asset (implemented as `CANCEL_ADD` + verbatim `ADD`; Remove-step independent).
- Tag length filter (`Length` field) alongside the free-text ("manual") search in the
  Manual Tag Editor and the Review → Add step; shared `core/sanitizer.tag_char_length()`.
