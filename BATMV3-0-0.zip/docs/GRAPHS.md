# BATM — Flow Graphs

These graphs are the active development model for BATM, not decoration. They
mirror the real flow in the code (core → engine → operators → ui). If a graph
and the code ever disagree, **do not hide it**: fix whichever one is wrong (the
SSOT is the final authority). The four stages are **Add, Remove, Cleanup, Last
Step** (equivalents of Tags to Add, Tags to Remove, Sanitizer, Asset Fine
Tuning). Only the three transform stages (Add / Remove / Cleanup) feed the
Reducer; Last Step is the per-asset fine-tune + Final-Tags confirmation stage
and introduces no tag transform.

---

## 1. Global Flow

```
SELECTION
   ↓
FREEZE                       (stable asset identities: library, path, id_type, datablock)
   ↓
PREFLIGHT
   ↓
SNAPSHOT                     (read-only tags + fingerprints)
   ↓
ANALYSIS                     (AutoTag engine + Knowledge + concept catalog + Manual queue)
   ↓
STAGE CONTROL                (add/remove/cleanup/last_step ON/OFF)
   ↓
ACTIVE PIPELINE              (only the active stages emit operations)
   ↓
REDUCER                      (compiles active operations into a desired final state)
   ↓
FINAL PLAN
   ↓
PREVIEW                      (editable model = the plan; never Blender state)
   ↓
APPROVAL
   ↓
VALIDATION
   ↓
BACKUP
   ↓
EXECUTE
   ↓
VERIFY
   ├── SUCCESS → REFRESH → IDLE
   │
   └── FAILURE → CLASSIFY
                    ↓
              ¿write occurred?
                 ├── NO → FAIL / REPORT
                 └── YES → RESTORE
                             ↓
                         VERIFY RESTORE → RESTORED / ERROR
```

---

## 2. Stage Control — 16 combinations

Stages evaluated in fixed order: `Add → Remove → Cleanup → Last Step`.
An OFF stage generates no operations, modifies no plan, produces no diff and
counts as no executed work.

```
0000 → NO-OP
0001 → Last Step
0010 → Cleanup
0011 → Cleanup → Last Step
0100 → Remove
0101 → Remove → Last Step
0110 → Remove → Cleanup
0111 → Remove → Cleanup → Last Step
1000 → Add
1001 → Add → Last Step
1010 → Add → Cleanup
1011 → Add → Cleanup → Last Step
1100 → Add → Remove
1101 → Add → Remove → Last Step
1110 → Add → Remove → Cleanup
1111 → Add → Remove → Cleanup → Last Step
```

```
ANALYSIS
   ↓
STAGE CONTROL
   ├─ Add ON?    ── YES → ADD    / NO → SKIP
   ├─ Remove ON? ── YES → REMOVE / NO → SKIP
   ├─ Cleanup ON?── YES → CLEANUP/ NO → SKIP
   └─ Last Step ON? YES → LAST STEP / NO → SKIP
                       ↓
                     REDUCER
                       ↓
                     PREVIEW
```

---

## 3. Data Flow

Never confuse the **Preview model** with the **real Blender state**.

```
SOURCE DATA
   ↓
ANALYSIS
   ↓
CANDIDATES
   ↓
RAW OPERATIONS
   ↓
STAGE FILTER                 (only active stages)
   ↓
ACTIVE OPERATIONS
   ↓
TRANSFORMATIONS              (Cleanup: normalize / dedup / compound / numbers)
   ↓
REDUCER
   ↓
REDUCED PLAN
   ↓
PREVIEW MODEL                (what the user reviews)
   ↓
APPROVAL
   ↓
APPROVED PLAN                (same object as the previewed plan)
   ↓
EXECUTION REQUEST
   ↓
REAL BLENDER STATE
```

Any change to an earlier stage invalidates every derived result that depends on
it (operations → Cleanup → Reducer → Preview) and rebuilds them; stale derived
results are never reused.

---

## 4. Cleanup (Sanitizer)

Cleanup is the existing Sanitizer re-used as the normalization / repair /
validation layer. It operates on the **plan**, never on real assets.

```
INPUT
 ↓
TOKENIZE
 ↓
TRIM
 ↓
WHITESPACE NORMALIZATION
 ↓
SEPARATOR NORMALIZATION       (COMMA/SEMICOLON/SPACE/PIPE/DOUBLE_HYPHEN)
 ↓
REMOVE EMPTY
 ↓
CASING
 ↓
CASEFOLD (DEDUP KEY)
 ↓
DEDUP
 ↓
SYNONYM / BLACKLIST RULES
 ↓
COMPOUND WORD PROCESSING       (Split Compound Words)
 ↓
REMOVE TRAILING NUMBERS        (default ON)
 ↓
CONFLICT RESOLUTION
 ↓
REPAIR INTERMEDIATE ERRORS     (e.g. undo an over-split w/ evidence)
 ↓
VALIDATION                     (length ≤ 63, control chars, per-asset cap)
 ↓
FINAL TAGS
```

---

## 5. Compound Words

The **combined** representation is the semantically correct unit derived from
the segmentation evidence — it is *not* always the raw token and *not* always
`"-".join(parts)`:
* a **curated thesaurus split** preserves the original token (`promeshchild`);
* a **lexical-discovery split** rejoins its components through normal
  casing/separators (`oaktree` → `oak tree`).

The combined form is appended as plain text and is **never** fed back into the
segmenter, so a validated representation cannot be re-split.

```
RAW TAG
   ↓
Split Compound Words?
   ├─ OFF → PRESERVE ORIGINAL
   │
   └─ ON
       ↓
     DETECT COMPOUND
       ↓
     OBTAIN VALIDATED COMPONENTS
       ↓
     ¿EVIDENCE SUFFICIENT?
       ├─ NO → PRESERVE ORIGINAL          (e.g. promesh → promesh, never pro+mesh)
       │
       └─ YES
           ↓
         DETERMINE SEMANTIC COMBINED REPRESENTATION
           ↓
         VALIDATE COMBINED REPRESENTATION
           ↓
         MODE
           ├─ SPLIT     → valid components only
           ├─ COMBINED  → valid combined representation only
           └─ BOTH      → valid combined representation + valid components
           ↓
         DEDUPLICATE
           ↓
         VALIDATE FINAL
```

---

## 6. Reactive Preview

Every user change goes through one guarded recompile path (`_live_recompile`
→ `options_from_props` → `recompile_preserving_disabled`). It runs only during
`REVIEW_READY`, never writes Blender assets, never creates a backup and never
executes. A reentrancy guard collapses property-update cascades into a single
rebuild.

```
USER CHANGE            (Add / Remove / Cleanup / Last Step / Split / Combined / Cleanup settings)
   ↓
UPDATE SHARED STATE
   ↓
¿REVIEW_READY?
   ├─ NO → no-op
   └─ YES
        ↓
      ¿recompiling? → YES → no-op
      └─ NO
           ↓
         mark guard
           ↓
         rebuild affected plan
           ↓
         release guard
           ↓
         PREVIEW UPDATE
```

The same plan object feeds Preview and Execute — a modification invalidates the
earlier approval and rebuilds the plan before a new Preview.

---

## 7. Error / Recovery

```
PROCESS
   ↓
¿SUCCESS?
   ├─ YES → NEXT
   │
   └─ NO
        ↓
      CLASSIFY
        ↓
      ¿write already occurred?
         ├─ NO → FAIL / REPORT / RETRY (by contract)
         │
         └─ YES → RESTORE (from verified backup)
                    ↓
                  VERIFY RESTORE
                    ├─ YES → RESTORED
                    └─ NO  → CRITICAL RECOVERY ERROR
```

If an error can be repaired before writing: repair → invalidate derived data →
rebuild → validate → continue. Never execute with stale derived data.

---

## 8. Transactional Execution

Preview + Approval + Validation + verified Backup before any write; SUCCESS
requires a write plus a post-write verification.

```
IDLE
 ↓  Run BATM
ANALYZING
 ↓
REVIEW_READY
 ↓  Confirm
APPROVED
 ↓
BACKING_UP
 ↓  backup verified
BACKED_UP
 ↓
EXECUTING
 ├── SUCCEEDED → REFRESHING → IDLE
 ├── CANCEL_REQUESTED → RESTORING → RESTORED → REFRESHING → IDLE
 ├── PARTIAL_FAILED → RESTORING → RESTORED → REFRESHING → IDLE
 └── FAILED → RESTORING → RESTORED → REFRESHING → IDLE
                    └── RESTORE FAILED → FAILED (recovery backup retained)
```

---

## 9. Development / Implementation Flow

The graph is a checkpoint for every change: implement, validate, and reconcile
graph ↔ code before moving on. If a repair sends the flow back to an earlier
stage, return there explicitly and rebuild everything that depends on it.

```
PLAN
 ↓
IDENTIFY AFFECTED NODE
 ↓
DEFINE INPUT / OUTPUT
 ↓
IMPLEMENT
 ↓
VALIDATE
 ↓
¿CODE MATCHES GRAPH?
   ├─ YES → NEXT NODE / PHASE
   │
   └─ NO
       ↓
     DIAGNOSE
       ↓
     ¿IS THE CODE WRONG?
       ├─ YES → REPAIR CODE
       └─ NO  → CORRECT GRAPH / PLAN
       ↓
     INVALIDATE DERIVED RESULTS
       ↓
     REVALIDATE
       ↓
     CONTINUE
```

---

## Traceability

```
SOURCE → STAGE → OPERATION → TRANSFORMATION → FINAL RESULT
  │         │          │            │              │
Add      Rule / Knowledge / Manual → Cleanup normalize → Final Tags
Remove   Rule / Manual              → Cleanup dedup     → Final Tags
Cleanup  normalization / repair                       → Final Tags
Last Step User fine-tune (no transform)               → Final Tags
```

Reasons survive Cleanup and the Reducer (`tag_reasons`), so every final Tag
keeps its provenance (AutoTag rule / Knowledge / Manual / taxonomy).

