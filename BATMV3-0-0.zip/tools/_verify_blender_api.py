"""Temporary dev script: verify Blender 5.2 API surface referenced by BATM.

Prints whether each documented attribute/operator exists in the 5.2 API docs.
This is a dev-time check only; it is excluded from the production ZIP.
"""
import re
import urllib.request
import html as html_mod

BASE = "https://docs.blender.org/api/5.2/"


def _text(slug: str) -> str:
    url = BASE + slug
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
    raw = urllib.request.urlopen(req, timeout=40).read().decode("utf-8", errors="ignore")
    text = re.sub(r"<[^>]+>", " ", raw)
    return html_mod.unescape(text)


def section(slug: str, terms: list[str]) -> None:
    text = _text(slug)
    print(f"== {slug} ==")
    for term in terms:
        print(f"  {term!r:45} {term in text}")
    print()


section("bpy.ops.asset.html", ["library_refresh", "catalog_new", "get_reference"])
section(
    "bpy.types.AssetRepresentation.html",
    ["full_library_path", "id_type", "is_online", "owner_asset_library", "local_id", "name"],
)
section(
    "bpy.types.FileAssetSelectParams.html",
    ["asset_library_reference", "asset_catalog_visibility"],
)
section("bpy.types.AssetLibraryReference.html", ["name"])
section("bpy.types.AssetMetaData.html", ["tags"])
section("bpy.types.BlendData.html", ["all_ids"])
section("bpy.ops.wm.html", ["open_mainfile", "save_as_mainfile"])
