"""Run every offline BATM test script in a subprocess and summarize results.

Usage:  python tests/_run_all.py
"""
import glob
import os
import subprocess
import sys

PY = sys.executable
HERE = os.path.dirname(os.path.abspath(__file__))


def main() -> int:
    files = sorted(glob.glob(os.path.join(HERE, "test_*.py")))
    passed = failed = 0
    for path in files:
        result = subprocess.run([PY, path], capture_output=True, text=True)
        name = os.path.basename(path)
        if result.returncode == 0:
            passed += 1
            print("PASS  " + name)
        else:
            failed += 1
            print("FAIL  %s  exit=%d" % (name, result.returncode))
            tail = (result.stdout + result.stderr).strip().splitlines()[-8:]
            for line in tail:
                print("      " + line)
    print("----")
    print("PASS=%d FAIL=%d" % (passed, failed))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
