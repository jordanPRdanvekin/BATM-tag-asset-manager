"""Prudent segmenter tests (no Blender) - behavior-driven, not word-driven.

The cases exercise *properties* (explicit separator, contiguous unknown token,
exact-known components, fixups, preserved invented tokens), not a vocabulary list.
Words here are structural fixtures only; they are not add-on knowledge.
"""
import sys  # noqa: F401
from _setup import ADDON_ROOT  # noqa: F401
from batm.engine.segmenter import collect_words, decompose, load_compound_splits
from batm.engine.knowledge import load_knowledge
from batm.engine.taxonomy import load_taxonomy
from batm.core.sanitizer import default_options, sanitize_tags  # noqa: E402,F401
_FIXUPS = dict(load_compound_splits())
lex = collect_words(load_knowledge(), load_taxonomy())

# Property: a full exact-known decomposition may split (oaktree -> oak, tree).
words, split = decompose("oaktree", lex)
assert split and set(words) == {"oak", "tree"}, (words, split)

# Property: a known single word is never split.
words, split = decompose("tree", lex)
assert not split and words == ["tree"], (words, split)

# Property: a contiguous token needing a *corrected* component is preserved.
# No Levenshtein correction is allowed to forge a boundary on a continuous token.
for word in ("fireforce", "klawitter", "apron", "conni"):
    words, split = decompose(word, lex)
    assert not split, (word, words)

# Property: an explicit separator yields a single combined Tag (via the Sanitizer).
_seg = {**default_options(), "segment": True, "segment_fixups": dict(_FIXUPS)}
assert sanitize_tags("fire_force", {**_seg, "casing": "TITLE"})[0] == ["Fire Force"]
assert sanitize_tags("fire-force", {**_seg, "casing": "TITLE"})[0] == ["Fire Force"]
assert sanitize_tags("fire force", {**_seg, "casing": "TITLE"})[0] == ["Fire Force"]

# Property: no separator + no full exact decomposition -> preserved intact.
# fireforce is contiguous; fire is known but force is not, so it is preserved.
assert sanitize_tags("fireforce", {**_seg, "casing": "TITLE"})[0] == ["Fireforce"]
assert sanitize_tags("fireforce", {**_seg, "casing": "NONE"})[0] == ["fireforce"]

# Property: casing and segmentation are independent.
assert sanitize_tags("oaktree", {**_seg, "casing": "TITLE"})[0] == ["Oak", "Oak Tree", "Tree"]
assert sanitize_tags("oaktree", {**_seg, "casing": "SNAKE"})[0] == ["oak", "oak_tree", "tree"]

# Property: curated fixups apply on an exact match only.
FIX = {"annasdad": ["annas", "dad"]}
words, split = decompose("annasdad", lex, fixups=FIX)
assert split and words == ["annas", "dad"], (words, split)
words, split = decompose("zzqxx", lex, fixups=FIX)
assert not split, (words, split)

# Property: memoization does not change output.
assert decompose("fireforce", lex) == decompose("fireforce", lex)

# Property: glued compounds of known words split (foxcub -> fox + cub,
# eyecornea -> eye + cornea); contextual terms like "cub" are lexicon words.
words, split = decompose("foxcub", lex)
assert split and words == ["fox", "cub"], (words, split)
words, split = decompose("eyecornea", lex)
assert split and words == ["eye", "cornea"], (words, split)

# Property: a separator-joined Tag whose sub-tokens are glued compounds is
# expanded into the components; separator-joined proper words stay combined
# (fire_force above). mat_foxcub_eyecornea -> mat, fox, cub, eye, cornea.
mat_split = sanitize_tags("mat_foxcub_eyecornea", {**_seg, "casing": "TITLE", "recombine": "SPLIT"})[0]
assert set(mat_split) == {"Mat", "Fox", "Cub", "Eye", "Cornea"}, mat_split
mat_both = sanitize_tags("mat_foxcub_eyecornea", {**_seg, "casing": "TITLE"})[0]
assert {"Mat", "Fox", "Cub", "Eye", "Cornea"} <= set(mat_both), mat_both
assert "Fox Cub" in mat_both and "Eye Cornea" in mat_both, mat_both

print("SEGMENTER TESTS OK")
