"""Stage pipeline: 16 combinations, active-only reducer, no-op, defaults (no Blender).

Order of the four stages is fixed: Add -> Remove -> Cleanup -> Last Step.
Only the three transform stages (Add / Remove / Cleanup) feed the Reducer;
Last Step is the per-asset fine-tune + Final-Tags confirmation stage and
introduces no tag transform, so it is never a data stage. Stage flips below
verify that OFF stages generate no operations and never modify the plan.
"""
import sys  # noqa: F401
from types import SimpleNamespace

from _setup import ADDON_ROOT  # noqa: F401,E402

from batm.core.models import AssetKey, AssetSnapshot, TagOperation  # noqa: E402
from batm.core.reducer import compile_states  # noqa: E402
from batm.core.sanitizer import default_options, options_from_props  # noqa: E402

TOKEN = "Lib|C:/lib/a.blend|OBJECT|A"

ADD_OP = TagOperation(kind="ADD", targets=[TOKEN], values=["New"], origin="MANUAL")
REM_OP = TagOperation(kind="REMOVE", targets=[TOKEN], values=["Old"], origin="MANUAL")

# Bit layout, most significant first: Add, Remove, Cleanup, Last Step.
# 0000 -> NO-OP; 1111 -> Add -> Remove -> Cleanup -> Last Step.
BIT_ADD = 0b1000
BIT_REMOVE = 0b0100
BIT_CLEANUP = 0b0010
BIT_LAST = 0b0001

EXPECTED = {
    0b0000: "NO-OP",
    0b0001: "Last Step",
    0b0010: "Cleanup",
    0b0011: "Cleanup -> Last Step",
    0b0100: "Remove",
    0b0101: "Remove -> Last Step",
    0b0110: "Remove -> Cleanup",
    0b0111: "Remove -> Cleanup -> Last Step",
    0b1000: "Add",
    0b1001: "Add -> Last Step",
    0b1010: "Add -> Cleanup",
    0b1011: "Add -> Cleanup -> Last Step",
    0b1100: "Add -> Remove",
    0b1101: "Add -> Remove -> Last Step",
    0b1110: "Add -> Remove -> Cleanup",
    0b1111: "Add -> Remove -> Cleanup -> Last Step",
}


def snap(before=("Old",)):
    key = AssetKey(
        library_reference="Lib", blend_path="C:/lib/a.blend", id_type="OBJECT", datablock_name="A"
    )
    return AssetSnapshot(key=key, tags=list(before))


def compile_for(bitmask):
    opts = {
        **default_options(),
        "enable_add": bool(bitmask & BIT_ADD),
        "enable_remove": bool(bitmask & BIT_REMOVE),
        "enable_cleanup": bool(bitmask & BIT_CLEANUP),
    }
    return next(iter(compile_states([snap()], [ADD_OP, REM_OP], opts).values()))


for bitmask, label in EXPECTED.items():
    state = compile_for(bitmask)
    # Add stage controls whether ADD operations are applied.
    if bitmask & BIT_ADD:
        assert "New" in state.after, (label, state.after)
    else:
        assert "New" not in state.after, (label, state.after)
    # Remove stage controls whether REMOVE operations are applied.
    if bitmask & BIT_REMOVE:
        assert "Old" not in state.after, (label, state.after)
    else:
        assert "Old" in state.after, (label, state.after)
    # 0000 -> NO-OP: no operation applied, no diff.
    if bitmask == 0b0000:
        assert state.after == ["Old"], (label, state.after)
        assert not state.changed, (label, state.after)

# Full pipeline: Add then Remove then Cleanup produce the final-state plan.
full = compile_for(0b1111)
assert "New" in full.after and "Old" not in full.after, full.after
# Remove-only removes the existing tag and never adds.
remove_only = compile_for(0b0100)
assert "Old" not in remove_only.after and "New" not in remove_only.after, remove_only.after

# --- Shared options path maps the four stage toggles onto the reducer flags and
# defaults Split Compound Words / Remove Trailing Numbers ON (UI drives Preview
# from these same options; Enable All / Disable All just flip the four toggles). ---
props = SimpleNamespace(
    sanitize_separators="COMMA_SEMICOLON",
    sanitize_casing="TITLE",
    sanitize_sort=True,
    sanitize_max_length=63,
    sanitize_remove_numbers=True,
    sanitize_merge_synonyms=False,
    sanitize_max_tags=0,
    sanitize_segment=True,
    sanitize_recombine="BOTH",
    sanitize_blacklist="",
    review_add_on=True,
    review_remove_on=True,
    review_cleanup_on=True,
    review_assets_on=True,
)
opts = options_from_props(props)
assert opts["segment"] is True
assert opts["remove_isolated_numbers"] is True
assert opts["enable_add"] and opts["enable_remove"] and opts["enable_cleanup"]
assert opts["enable_assets"] is True

# Last Step (per-asset fine-tune): PREVIEW operations apply only while the
# stage is on; other origins are unaffected by the toggle.
preview_add = TagOperation(kind="ADD", targets=[TOKEN], values=["Fine"], origin="PREVIEW")
last_off = SimpleNamespace(**props.__dict__)
last_off.review_assets_on = False
opts_last_off = options_from_props(last_off)
assert opts_last_off["enable_assets"] is False
st_off = next(iter(compile_states([snap()], [ADD_OP, preview_add], opts_last_off).values()))
assert "New" in st_off.after and "Fine" not in st_off.after, st_off.after
st_on = next(iter(compile_states([snap()], [ADD_OP, preview_add], opts).values()))
assert "Fine" in st_on.after, st_on.after
# Disable All -> every stage off -> reducer runs as a no-op.
disabled = SimpleNamespace(**props.__dict__)
for name in ("review_add_on", "review_remove_on", "review_cleanup_on", "review_assets_on"):
    setattr(disabled, name, False)
disabled_opts = options_from_props(disabled)
assert not disabled_opts["enable_add"]
assert not disabled_opts["enable_remove"]
assert not disabled_opts["enable_cleanup"]
noop = next(iter(compile_states([snap()], [ADD_OP, REM_OP], disabled_opts).values()))
assert not noop.changed, noop.after

print("STAGE PIPELINE (16 combinations) OK")
