"""Add-step exclusion tests (no Blender).

Verifies the Add-step "do not add this Tag" semantic:
  * excluding a proposed Tag stops it from being (re-)added by Add/AutoTag;
  * it works regardless of the Remove step toggle;
  * it does NOT touch Tags that already exist on an asset.
Property-based, using structural fixtures only (no vocabulary contract).
"""
import sys  # noqa: F401
from _setup import ADDON_ROOT  # noqa: F401

from batm.core.models import AssetKey, AssetSnapshot, TagOperation  # noqa: E402
from batm.core.reducer import compile_states  # noqa: E402
from batm.core.sanitizer import default_options  # noqa: E402


def _key(name="A"):
    return AssetKey("Lib", "C:/lib/a.blend", "OBJECT", name)


def _compile(tags, ops, **over):
    snapshot = AssetSnapshot(key=_key(), tags=list(tags), writable=True)
    return compile_states([snapshot], ops, _opts_over(**over))[_key().token]


def _opts_over(**over):
    return {**default_options(), "enable_add": True, "enable_remove": True,
            "enable_cleanup": True, "casing": "TITLE", **over}


ADD_SWORD = TagOperation(kind="ADD", targets=[_key().token], values=["Sword"], origin="AUTO", explanation="Auto")
CANCEL_SWORD = TagOperation(kind="CANCEL_ADD", targets=[_key().token], values=["Sword"], origin="PREVIEW")


def test_exclusion_blocks_added_tag():
    # Proposed-new Tag is excluded -> not present in the final set.
    st = _compile([], [ADD_SWORD, CANCEL_SWORD])
    assert "Sword" not in [t.casefold() for t in st.after], st.after
    assert st.changed is False, (st.added, st.removed)


def test_exclusion_works_with_remove_off():
    # Even with the Remove step disabled, the Add-step exclusion still applies.
    st = _compile([], [ADD_SWORD, CANCEL_SWORD], enable_remove=False)
    assert "Sword" not in [t.casefold() for t in st.after], st.after


def test_exclusion_does_not_touch_existing_tag():
    # An existing Tag on the asset is unaffected by the exclusion.
    st = _compile(["Sword"], [CANCEL_SWORD])
    assert any(t == "sword" for t in (x.casefold() for x in st.after)), st.after
    assert not st.removed, st.removed


def test_exclusion_blocked_when_add_off():
    # If the Add step is off, nothing is added anyway (exclusion is a no-op).
    st = _compile([], [ADD_SWORD, CANCEL_SWORD], enable_add=False)
    assert "Sword" not in [t.casefold() for t in st.after], st.after


def test_exclusion_is_idempotent():
    # Re-scanning an already-excluded state yields NO CHANGE.
    st = _compile([], [ADD_SWORD, CANCEL_SWORD])
    again = _compile(list(st.after), [CANCEL_SWORD])
    assert not again.changed, (again.added, again.removed)


for fn in (test_exclusion_blocks_added_tag, test_exclusion_works_with_remove_off,
           test_exclusion_does_not_touch_existing_tag, test_exclusion_blocked_when_add_off,
           test_exclusion_is_idempotent):
    fn()

print("ADD EXCLUSION TESTS OK")