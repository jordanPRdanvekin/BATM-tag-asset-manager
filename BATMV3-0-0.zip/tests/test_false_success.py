"""Scheduler must never treat empty/partial/failed results as success (no Blender).

Guards the "false-positive success" class: a worker that terminates is only a
*success* when the parent both sees exit code 0 AND a result dict with
``success == True``. Anything else (empty or missing result, explicit failure,
cancellation, nonzero exit) must land in ``failed`` so the run reports failure /
triggers rollback instead of claiming success.
"""
import sys
import types

from _setup import ADDON_ROOT  # noqa: F401,E402

# --- Stub bpy so importing engine.scheduler (which pulls adapters) works offline.
bpy = types.ModuleType("bpy")
bpy.utils = types.SimpleNamespace(user_resource=lambda *a, **k: ADDON_ROOT + r"\.batm_test")
sys.modules["bpy"] = bpy

from batm.engine import scheduler as S  # noqa: E402
from batm.engine.scheduler import BatchScheduler, RunningJob  # noqa: E402


class FakeProc:
    """A process stub whose `poll()` returns a fixed exit code once."""

    def __init__(self, code: int):
        self._code = code

    def poll(self) -> int:
        return self._code

    def kill(self) -> None:
        pass

    def wait(self) -> None:
        pass


_RESULT_PATH = "C:/r/result.json"
_OVERRIDES: dict = {}


def _read_json(path, default=None):
    if path == _RESULT_PATH:
        return _OVERRIDES.get(_RESULT_PATH) or {}
    return default


S.read_json = _read_json
S.command_for = lambda prepared: ["python", "-c", "pass"]
S.request_cancel = lambda jobs: None


def _poll_one(result: dict, exit_code: int) -> BatchScheduler:
    _OVERRIDES[_RESULT_PATH] = result
    prepared = {"result_path": _RESULT_PATH, "status_path": "C:/r/s.json", "request": {"mode": "APPLY"}}
    sched = BatchScheduler(pending=[], max_workers=1)
    sched.running = [RunningJob(prepared=prepared, process=FakeProc(exit_code), deadline=1_000_000)]
    sched.poll()
    return sched


def main():
    # Empty / missing result + exit 0 -> FAILED (not success).
    s = _poll_one({}, 0)
    assert not s.completed and len(s.failed) == 1, "empty result must fail"

    # Explicit failure + exit 0 -> FAILED (worker wrote failure but exited 0).
    s = _poll_one({"success": False, "error": "boom"}, 0)
    assert not s.completed and s.failed

    # Cancellation result -> FAILED.
    s = _poll_one({"success": False, "cancelled": True, "error": "x"}, 0)
    assert not s.completed and s.failed

    # success:True but nonzero exit -> FAILED (process exit is part of the chain).
    s = _poll_one({"success": True, "assets": ["a"]}, 1)
    assert not s.completed and s.failed

    # success:True + exit 0 -> COMPLETED.
    s = _poll_one({"success": True, "assets": ["a"]}, 0)
    assert s.completed and not s.failed

    # A run that ends with any failed job is never `done`-as-success: the modal
    # checks scheduler.failed first, so this must be detectable.
    s = _poll_one({"success": False, "error": "boom"}, 0)
    assert s.done and s.failed, "failed job must surface and mark the run finished-as-failed"

    print("FALSE-SUCCESS SCHEDULER OK")


main()
