"""Per-step activation and live compound recombine / segmentation repair (no Blender)."""
import sys  # noqa: F401

from _setup import ADDON_ROOT  # noqa: F401,E402

from batm.core.models import AssetKey, AssetSnapshot, TagOperation  # noqa: E402
from batm.core.reducer import compile_states  # noqa: E402
from batm.core.sanitizer import default_options, sanitize_tags  # noqa: E402
from batm.engine.segmenter import load_compound_splits  # noqa: E402

FIXUPS = load_compound_splits()

TOKEN = "Lib|C:/lib/a.blend|OBJECT|A"


def snap(tags):
    key = AssetKey(
        library_reference="Lib", blend_path="C:/lib/a.blend", id_type="OBJECT", datablock_name="A"
    )
    return AssetSnapshot(key=key, tags=list(tags))


def s(vals, **over):
    opts = {
        **default_options(),
        "segment": True,
        "segment_fixups": dict(FIXUPS),
        **over,
    }
    return sanitize_tags(vals, opts)[0]


def tags(vals, **over):
    return {tag.casefold() for tag in s(vals, **over)}


# --- Compound Words (Section O): SPLIT / COMBINED / BOTH contract. ---
#
# The combined representation is the semantically correct unit derived from the
# split evidence — never always the raw token and never blindly "-".join(...):
#   * curated thesaurus split -> keeps the original token (promeshchild);
#   * lexical discovery split  -> rejoins components via casing/separators
#     (oaktree -> "oak tree").
# SPLIT shows only the validated components; COMBINED holds only the validated
# combined unit; BOTH holds the combined unit plus the components. Nothing is
# handed back to the segmenter, so a validated representation is never reshaped.

# promesh: no strong evidence to split -> preserved in every mode (NOT pro+mesh).
for mode in ("SPLIT", "RECOMBINED", "BOTH"):
    seg = tags(["promesh"], recombine=mode)
    assert seg == {"promesh"}, (mode, seg)
    assert "pro" not in seg and "mesh" not in seg, (mode, seg)

# promeshchild: curated evidence -> promesh + child.
child_split = tags(["promeshchild"], recombine="SPLIT")
assert child_split == {"promesh", "child"}, child_split
assert "promeshchild" not in child_split and "pro" not in child_split, child_split
child_combined = tags(["promeshchild"], recombine="RECOMBINED")
assert child_combined == {"promeshchild"}, child_combined  # NOT "promesh-child"
child_both = tags(["promeshchild"], recombine="BOTH")
assert child_both == {"promeshchild", "promesh", "child"}, child_both
assert "promesh-child" not in child_both, child_both

# oaktree: lexical discovery -> oak + tree, combined "oak tree".
oak_split = tags(["oaktree"], recombine="SPLIT")
assert oak_split == {"oak", "tree"}, oak_split
oak_combined = tags(["oaktree"], recombine="RECOMBINED")
assert oak_combined == {"oak tree"}, oak_combined  # NOT "oak-tree"
oak_both = tags(["oaktree"], recombine="BOTH")
assert oak_both == {"oak", "tree", "oak tree"}, oak_both
assert "oak-tree" not in oak_both, oak_both
# The already-validated combined form is never fed back into decomposition.
assert "oaktree" not in oak_split, oak_split

# Remove Trailing Numbers (now on by default in the UI, verified in the engine).
cleaned = sanitize_tags(["Rock_01"], {**default_options(), "remove_isolated_numbers": True})[0]
assert all("01" not in tag for tag in cleaned), cleaned
assert "Rock" in cleaned, cleaned


def compile_with(ops, **flags):
    opts = {**default_options(), **flags}
    result = compile_states([snap(["Prefab", "Old"])], ops, opts)
    return next(iter(result.values()))


add_op = TagOperation(kind="ADD", targets=[TOKEN], values=["New"], origin="MANUAL")
rem_op = TagOperation(kind="REMOVE", targets=[TOKEN], values=["Old"], origin="MANUAL")

# Both steps active.
st = compile_with([add_op, rem_op], enable_add=True, enable_remove=True, enable_cleanup=True)
assert "New" in st.after and "Old" not in st.after, st.after
# Add step disabled.
st = compile_with([add_op, rem_op], enable_add=False, enable_remove=True)
assert "New" not in st.after, f"Add disabled but tag added: {st.after}"
# Remove step disabled.
st = compile_with([add_op, rem_op], enable_add=True, enable_remove=False)
assert "Old" in st.after, f"Remove disabled but tag removed: {st.after}"
# Cleanup step off: no casing / sort normalization is applied.
raw = snap(["oak_tree"])
opts = {**default_options(), "enable_cleanup": False}
state = next(iter(compile_states([raw], [], opts).values()))
assert "oak_tree" in state.after and "oak_tree" not in ["Oak Tree"], state.after

print("STEPS / RECOMBINE / REPAIR TESTS OK")