"""Reconciliation / repair tests (no Blender) — property-based, not word-driven.

Verifies the general reconciliation contract:
  * BEFORE -> EXPECED AFTER via the reducer (`compile_states`);
  * the Diff exposes correct ADD / REMOVE / KEEP for normalized / merged Tags;
  * the whole pipeline is idempotent: applying the diff and re-scanning yields
    NO CHANGE (unless some external fact actually changed).
Uses structural fixtures rather than a vocabulary list.
"""
import sys  # noqa: F401
from _setup import ADDON_ROOT  # noqa: F401

from batm.core.models import AssetKey, AssetSnapshot  # noqa: E402
from batm.core.reducer import compile_states  # noqa: E402
from batm.core.sanitizer import default_options  # noqa: E402


def _key(name):
    return AssetKey("Lib", "C:/lib/a.blend", "OBJECT", name)


def _opts(**over):
    return {**default_options(), "enable_cleanup": True, "casing": "TITLE", "sort": True, **over}


def _compile(tags, **over):
    key = _key("A")
    snapshot = AssetSnapshot(key=key, tags=list(tags), writable=True)
    return compile_states([snapshot], [], _opts(**over))[key.token]


# --- Property: an existing Tag that normalizes away from its canonical form is
# reported as a real REPAIR diff (REMOVE old + ADD canonical), not left in place. ---
state = _compile(["oak_tree", "Character"], merge_synonyms=True, synonyms={"oak": "Wood"})
assert "oak_tree" in state.removed, state.removed
assert "Oak Tree" in state.added, state.added
assert "Character" not in state.removed and "Character" in state.after, state
assert state.changed, state.changed

# --- Property: synonym merging canonicalizes an existing Tag (Wolf -> Animal). ---
state = _compile(["Wolf", "Character"], merge_synonyms=True, synonyms={"wolf": "Animal"})
assert state.removed == ["Wolf"], state.removed
assert state.added == ["Animal"], state.added
assert state.after == ["Animal", "Character"], state.after

# --- Property: a once-repaired state is idempotent — re-scanning yields NO CHANGE. ---
repaired = _compile(["Wolf", "Character"], merge_synonyms=True, synonyms={"wolf": "Animal"})
again = _compile(list(repaired.after), merge_synonyms=True, synonyms={"wolf": "Animal"})
assert not again.changed, (again.added, again.removed)
assert again.after == repaired.after, again.after

# --- Property: KEEP tags that are already canonical are untouched. ---
state = _compile(["Character", "Wood", "oak_tree"], merge_synonyms=True, synonyms={"oak": "Wood"})
# "Wood" and "Character" are stable; "oak_tree" normalizes to "Oak Tree".
assert state.removed == ["oak_tree"], state.removed
assert state.added == ["Oak Tree"], state.added
assert set(state.after) == {"Character", "Oak Tree", "Wood"}, state.after

print("RECONCILE / REPAIR TESTS OK")