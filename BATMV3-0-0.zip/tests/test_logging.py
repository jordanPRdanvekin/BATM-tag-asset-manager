"""Centralized diagnostics contract test (no Blender).

Stubs ``bpy`` and ``batm.adapters.storage`` so ``engine.logging`` can be
exercised offline. Verifies that ``capture_exception``:
  * records full evidence (exception, cause, file, function, line, traceback);
  * reports the manifest add-on version and the (stubbed) Blender version;
  * never raises, even when the primary *and* fallback log destinations fail.
"""
import sys  # noqa: F401
import types
from pathlib import Path  # noqa: F401
from _setup import ADDON_ROOT  # noqa: F401,E402

# --- Stub bpy so _blender_version_string() is deterministic and offline-safe.
if "bpy" not in sys.modules:
    bpy = types.ModuleType("bpy")
    app = types.ModuleType("bpy.app")
    app.version_string = "5.2.0-test"
    bpy.app = app
    sys.modules["bpy"] = bpy
    sys.modules["bpy.app"] = app

# --- Stub batm.adapters.storage (the real one imports bpy).
_adapter = types.ModuleType("batm.adapters")
_adapter.__path__ = []
_storage = types.ModuleType("batm.adapters.storage")
_storage.atomic_json_write = lambda path, value: Path(path)
_storage.ensure_dirs = lambda: {"logs": Path("."), "base": Path(".")}
_storage.read_json = lambda path, default=None: default
_adapter.storage = _storage
sys.modules.setdefault("batm.adapters", _adapter)
sys.modules.setdefault("batm.adapters.storage", _storage)

from batm.engine import logging as L  # noqa: E402

# --- Test 1: record shape, evidence and versions (never raises).
_persisted = {}
_orig_persist = L.persist_diagnostic
L.persist_diagnostic = lambda rec: _persisted.update(rec) or Path("x")

try:
    1 / 0
except ZeroDivisionError as exc:
    rec = L.capture_exception(
        code="TEST", message="boom", operation="op", phase="IDLE", exc=exc
    )

assert rec["exception"] == "ZeroDivisionError"
assert rec["cause"] == "division by zero"
assert "ZeroDivisionError" in rec["traceback"]
assert rec["operation"] == "op" and rec["phase"] == "IDLE"
assert rec["addon_version"] == "3.0.0", rec["addon_version"]
assert rec["blender_version"] == "5.2.0-test"
assert rec["file"] and rec["function"] and rec["linenum"]
assert _persisted.get("code") == "TEST"

# --- Test 2: primary and fallback failures never raise (stderr last resort).
L.persist_diagnostic = _orig_persist


def _bomb_dir():
    raise OSError("no disk")


L.ensure_dirs = _bomb_dir
L.atomic_json_write = _bomb_dir
rec = L.capture_exception(code="FALLBACK", message="x", exc=RuntimeError("r"))
assert rec["cause"] in ("r", "UNKNOWN")
L.ensure_dirs = _storage.ensure_dirs
L.atomic_json_write = _storage.atomic_json_write

print("LOGGING DIAGNOSTICS OK")
