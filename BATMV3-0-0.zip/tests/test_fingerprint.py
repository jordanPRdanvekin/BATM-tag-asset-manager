"""Fingerprint determinism and change detection (no Blender).

``engine/fingerprint`` is bpy-free (hashlib + pathlib), so this is pure offline
validation of the fingerprint contract used by analysis, apply and restore.
"""
import tempfile
from pathlib import Path

from _setup import ADDON_ROOT  # noqa: F401,E402

from batm.engine.fingerprint import fingerprint_file, fingerprints_match  # noqa: E402


def _write(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")


def main():
    with tempfile.TemporaryDirectory() as folder:
        p = Path(folder) / "a.blend"
        _write(p, "hello")
        fp1 = fingerprint_file(str(p))
        # Standard fingerprint fields populated.
        assert {"size", "mtime_ns", "sha256"} <= set(fp1), fp1
        assert fp1["sha256"] and fp1["size"] > 0
        # Same file matches itself; sha256 deterministic for identical content.
        assert fingerprints_match(fp1, fingerprint_file(str(p)))
        q = Path(folder) / "b.blend"
        _write(q, "hello")
        assert fingerprint_file(str(q))["sha256"] == fp1["sha256"]
        # Content change is detected (size or digest differ).
        _write(p, "world")
        fp2 = fingerprint_file(str(p))
        assert not fingerprints_match(fp1, fp2)
        # An empty/absent fingerprint never matches a real one.
        assert not fingerprints_match({}, fp2)
        assert not fingerprints_match(fp2, {})
    print("FINGERPRINT TESTS OK")


main()
