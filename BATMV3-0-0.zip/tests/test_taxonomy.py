"""Concept catalog tests (no Blender)."""
import sys  # noqa: F401

from _setup import ADDON_ROOT  # noqa: F401
from batm.core.models import AssetKey, AssetSnapshot
from batm.engine.taxonomy import load_taxonomy, merge_user_overrides, search_term, taxonomy_tags

KEY = AssetKey(library_reference="Lib", blend_path="C:/lib/a.blend", id_type="OBJECT", datablock_name="FoxChild")

def snap(facts):
    return AssetSnapshot(key=KEY, tags=[], writable=True, fingerprint={}, facts=dict(facts))

TAX = load_taxonomy()
assert TAX["domains"], "bundled taxonomy must load with domains"

# Catalog uses English tags and does not contain skirn (non-normative).
def test_no_skirn():
    blob = None
    for d in TAX["domains"]:
        for c in d["categories"]:
            for w in c["words"]:
                if str(w).casefold() == "skirn":
                    blob = w
    extra = TAX.get("aliases", {})
    assert blob is None and "skirn" not in {str(k).casefold() for k in extra}

# FULL catalog mode injects the domain label and the category tag.
def test_full_mode():
    s = snap({"name_tokens": ["oak", "table"]})
    tags = [t for t, _ in taxonomy_tags(s, TAX, "FULL", True)]
    assert "Nature" in tags and "Tree" in tags, tags
    assert "Furniture" in tags, tags  # table

# CONCEPTS mode emits only domain labels (primary concepts).
def test_concepts_mode():
    s = snap({"name_tokens": ["oak"]})
    tags = [t for t, _ in taxonomy_tags(s, TAX, "CONCEPTS", True)]
    assert "Nature" in tags, tags
    assert "Tree" not in tags, tags

# Cross-tagging off: no domain label, category still emitted in FULL.
def test_cross_off():
    s = snap({"name_tokens": ["oak"]})
    tags = [t for t, _ in taxonomy_tags(s, TAX, "FULL", False)]
    assert "Nature" not in tags, tags
    assert "Tree" in tags, tags

# Contextual age rule: fox + child -> pup (fauna), explained by a rule.
def test_contextual_fauna():
    s = snap({"name_tokens": ["fox", "child"]})
    results = taxonomy_tags(s, TAX, "FULL", True)
    tags = [t for t, _ in results]
    assert "pup" in tags, tags
    assert "Fauna" in tags, tags

# Contextual default: child alone (human context) stays human.
def test_contextual_human():
    s = snap({"name_tokens": ["child"]})
    tags = [t for t, _ in taxonomy_tags(s, TAX, "FULL", True)]
    assert "human" in tags, tags
    assert "pup" not in tags, tags

# Fauna evidence wins over the Human domain: an animal that is also named a
# "character" / "hero" is never tagged Human.
def test_fauna_beats_human():
    s = snap({"name_tokens": ["fox", "character"]})
    tags = [t for t, _ in taxonomy_tags(s, TAX, "FULL", True)]
    assert "Fauna" in tags and "Mammal" in tags, tags
    assert all(t.casefold() != "human" for t in tags), tags

# Glued compounds no longer hide fauna evidence: foxcub + child -> pup (fauna),
# never the human fallback.
def test_glued_compound_fauna():
    s = snap({"name_tokens": ["foxcub", "child"]})
    tags = [t for t, _ in taxonomy_tags(s, TAX, "FULL", True)]
    assert "pup" in tags, tags
    assert "Fauna" in tags, tags
    assert all(t.casefold() != "human" for t in tags), tags

# User overrides merge:
def test_merge_user_overrides():
    user = {"aliases": {"vegg": ["Food"]}, "contextual_terms": {}, "domains": [], "auxiliary": {}}
    merged = merge_user_overrides(TAX, user)
    assert merged["aliases"].get("vegg") == ["Food"]

# search_term finds a category for a known word, empty for unknown.
def test_search_term():
    assert search_term(TAX, "sword")
    assert [h for h in search_term(TAX, "sword") if h["kind"] == "category"][0]["tag"] == "Melee"
    assert search_term(TAX, "zzzznotthere") == []

if __name__ == "__main__":
    test_no_skirn(); test_full_mode(); test_concepts_mode(); test_cross_off()
    test_contextual_fauna(); test_contextual_human()
    test_fauna_beats_human(); test_glued_compound_fauna()
    test_merge_user_overrides(); test_search_term()
    print("TAXONOMY TESTS OK")
