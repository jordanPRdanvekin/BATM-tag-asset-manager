"""Hierarchy facts are usable rule fields and safe to match (D1)."""

from _setup import ADDON_ROOT  # noqa: F401

from batm.core.fields import ALLOWED_FIELDS, RULE_FIELDS
from batm.core.models import AssetKey, AssetSnapshot, Rule
from batm.core.rules import validate_rule
from batm.engine.autotag import build_autotag_operations, enrich_deep_facts, rule_matches
from batm.engine.extractors import extract_all

KEY = AssetKey(
    library_reference="Lib",
    blend_path="C:/lib/rig.blend",
    id_type="OBJECT",
    datablock_name="RobotArm",
)


def snapshot_with(facts):
    return AssetSnapshot(key=KEY, tags=[], writable=True, fingerprint={}, facts=dict(facts))


def test_hierarchy_fields_are_allowed():
    for field in ("bone_names", "constraint_types", "parent_names", "hierarchy_depth"):
        assert field in ALLOWED_FIELDS, field


def test_rule_fields_match_extractor_facts():
    """Every UI field must correspond to a fact produced by the extractors."""
    from types import SimpleNamespace

    class RNA:
        identifier = "OBJECT"

    class FakeObj:
        def __init__(self, name, obj_type, data=None):
            self.name = name
            self.type = obj_type
            self.data = data
            self.bl_rna = RNA()

    class FakeCollection:
        def __init__(self, name, objects):
            self.name = name
            self.all_objects = objects
            self.bl_rna = SimpleNamespace(identifier="COLLECTION")

    class FakeMaterial:
        def __init__(self, name):
            self.name = name
            self.bl_rna = SimpleNamespace(identifier="MATERIAL")

    def idents(blob):
        return SimpleNamespace(bl_rna=SimpleNamespace(identifier=blob))

    mesh = FakeObj("OakTree", "MESH", data=idents("MESH"))
    col = FakeCollection("Forest", [mesh, FakeObj("Rock", "MESH", data=idents("MESH"))])
    mat = FakeMaterial("Gold Metal")

    # Collect facts from a representative set of datablocks, enriched the same
    # way the AutoTag engine does before rules are evaluated.
    facts_sets = []
    for datablock, key_name in ((mesh, "OakTree"), (col, "Forest"), (mat, "GoldMetal")):
        key = AssetKey(
            library_reference="Test Lib",
            blend_path="C:/lib/file.blend",
            id_type=datablock.bl_rna.identifier,
            datablock_name=key_name,
        )
        snapshot = AssetSnapshot(key=key, facts=extract_all(datablock), writable=True)
        enrich_deep_facts(snapshot)
        facts_sets.append(snapshot.facts)
    produced = set()
    for facts in facts_sets:
        produced.update(facts.keys())

    # Every field in the UI contract must be produced by at least one extractor.
    for identifier, _label, _desc in RULE_FIELDS:
        assert identifier in produced, f"Rule field '{identifier}' has no corresponding extractor fact"


def test_rules_validate_with_hierarchy_fields():
    rule = Rule(
        name="Rigged prop",
        match_field="constraint_types",
        match_values=["TRACK_TO"],
        add_tags=["Rigged"],
    )
    assert validate_rule(rule) == []


def test_rule_matches_hierarchy_facts():
    snap = snapshot_with({"constraint_types": ["TRACK_TO", "LIMIT_LOCATION"]})
    rule = Rule(name="T", match_field="constraint_types", match_values=["track_to"], add_tags=["Rigged"])
    assert rule_matches(snap, rule)
    assert rule_matches(snap, Rule(name="A", match_field="bone_names", match_values=["root"], add_tags=["X"])) is False


def test_autotag_applies_hierarchy_rules():
    snap = snapshot_with(
        {
            "bone_names": ["root", "upper_arm"],
            "constraint_types": ["TRACK_TO"],
            "parent_names": ["Robot"],
            "hierarchy_depth": 4,
        }
    )
    rules = [
        Rule(name="R", match_field="bone_names", match_values=["upper_arm"], add_tags=["Armed"]),
        Rule(name="H", match_field="hierarchy_depth", match_values=["4"], add_tags=["Deep"]),
    ]
    ops = build_autotag_operations([snap], rules)
    values = [value for op in ops for value in op.values]
    assert "Armed" in values, values
    assert "Deep" in values, values


print("RULES HIERARCHY TESTS OK")