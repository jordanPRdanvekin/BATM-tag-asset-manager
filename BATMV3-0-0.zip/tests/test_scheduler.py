"""Scheduler watchdog/timeout test (no Blender required)."""

import sys
import time
import types

from _setup import ADDON_ROOT  # noqa: F401

bpy_stub = types.ModuleType("bpy")
bpy_stub.utils = types.SimpleNamespace(user_resource=lambda *a, **k: ADDON_ROOT + r"\.batm_test")
sys.modules["bpy"] = bpy_stub

from batm.engine import scheduler  # noqa: E402

scheduler.command_for = lambda prepared: ["python", "-c", "import time; time.sleep(60)"]
scheduler.read_json = lambda path, default=None: default
scheduler.request_cancel = lambda jobs: None

from batm.engine.scheduler import BatchScheduler  # noqa: E402


def test_timeout_kills_stuck_worker():
    pending = [
        {
            "result_path": "C:/tmp/result.json",
            "status_path": "C:/tmp/status.json",
            "request": {"assets": ["a"]},
            "timeout_seconds": 1,
        }
    ]
    sched = BatchScheduler(pending=pending, max_workers=1)
    sched.start_available()
    assert sched.running, "worker should start"
    time.sleep(1.4)
    sched.poll()
    assert not sched.running, "stuck worker must be removed"
    assert not sched.completed
    assert len(sched.failed) == 1, "stuck worker must land in failed"
    error = sched.failed[0]["result"].get("error", "")
    assert "deadline" in error and "killed" in error, f"unexpected error text: {error}"
    print("Scheduler watchdog OK")


def test_no_timeout_when_fast():
    pending = [
        {
            "result_path": "worker:/tmp/result.json",
            "status_path": "worker:/tmp/status.json",
            "request": {"assets": ["a1"]},
            "timeout_seconds": 30,
        }
    ]
    sched = BatchScheduler(pending=pending, max_workers=1)
    sched.start_available()
    time.sleep(0.2)
    sched.poll()
    assert sched.running, "fast job should still run within its deadline"
    assert not sched.failed
    sched.cancel()
    print("Scheduler ok with generous deadline")


def test_analysis_batch_plan():
    from batm.engine.scheduler import analysis_batch_plan

    # Fewer files than the worker target -> one batch per file.
    plan = analysis_batch_plan(3, 4)
    assert len(plan) == 3 and all(size == 1 for _start, size in plan), plan
    # Many files -> bounded, balanced batches that cover every file exactly once.
    plan = analysis_batch_plan(400, 4)
    assert len(plan) <= 4 * 4, len(plan)
    assert sum(size for _start, size in plan) == 400, plan
    starts = [start for start, _size in plan]
    assert len(starts) == len(set(starts)), starts
    sizes = sorted(size for _start, size in plan)
    assert sizes[-1] - sizes[0] <= 1, sizes
    # Zero files -> no batches.
    assert analysis_batch_plan(0, 4) == []
    print("Analysis batch plan OK")


def test_total_assets_counts_batched_files():
    from batm.engine.scheduler import BatchScheduler

    prepared = [
        {"request": {"files": [{"assets": ["a", "b"]}, {"assets": ["c"]}]}},
        {"request": {"assets": ["x"]}},
    ]
    sched = BatchScheduler(pending=prepared, max_workers=1)
    assert sched.total_assets == 4, sched.total_assets
    print("Scheduler total_assets (batched files) OK")


if __name__ == "__main__":
    test_timeout_kills_stuck_worker()
    test_no_timeout_when_fast()
    test_analysis_batch_plan()
    test_total_assets_counts_batched_files()
    print("SCHEDULER TESTS OK")