"""Backup manifest checksum validation, content and ordering (no Blender).

Stubs ``bpy`` and ``batm.adapters.storage`` so ``engine.backup`` (which imports
bpy and the package root) can be exercised offline against a temp directory.
"""
import json
import sys
import tempfile
import time
import types
from pathlib import Path

from _setup import ADDON_ROOT  # noqa: F401,E402

# --- Stub bpy (only bpy.app.version_string is used by engine.backup) ---
bpy = types.ModuleType("bpy")
bpy.app = types.ModuleType("bpy.app")
bpy.app.version_string = "5.2.0-test"
sys.modules["bpy"] = bpy
sys.modules["bpy.app"] = bpy.app

# The _setup harness registers `batm` as a stub package; give it BATM_VERSION_STRING.
batm = sys.modules["batm"]
batm.BATM_VERSION_STRING = "3.0.0"

TMP = Path(tempfile.mkdtemp(prefix="batm_backup_test_"))


def _write(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value), encoding="utf-8")


def _read_json(path, default=None):
    try:
        with Path(path).open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except Exception:
        return default


_storage = types.ModuleType("batm.adapters.storage")
_storage.ensure_dirs = lambda: {
    "base": TMP,
    "backups": TMP / "backups",
    "logs": TMP / "logs",
    "runs": TMP / "runs",
    "rules": TMP / "rules",
}
_storage.atomic_json_write = _write
_storage.read_json = _read_json
_adapter = types.ModuleType("batm.adapters")
_adapter.storage = _storage
sys.modules["batm.adapters"] = _adapter
sys.modules["batm.adapters.storage"] = _storage
_storage.ensure_dirs()["backups"].mkdir(parents=True, exist_ok=True)

from batm.core.models import AssetKey, AssetSnapshot, DesiredAssetState  # noqa: E402
from batm.engine import backup as B  # noqa: E402


def _snap(name: str, tags):
    key = AssetKey(
        library_reference="Lib",
        blend_path=f"C:/lib/{name}.blend",
        id_type="COLLECTION",
        datablock_name=name,
    )
    return AssetSnapshot(key=key, tags=list(tags), fingerprint={"size": 1, "mtime_ns": 2, "sha256": "x"})


def main():
    # Checksum is deterministic.
    assert B._checksum({"a": 1, "b": [1, 2]}) == B._checksum({"a": 1, "b": [1, 2]})

    # create_backup only records changed states and self-validates.
    snap = _snap("One", ["Old"])
    token = snap.key.token
    changed = DesiredAssetState(key=snap.key, before=["Old"], after=["Old", "New"])
    unchanged = DesiredAssetState(key=snap.key, before=["Old"], after=["Old"])
    path = B.create_backup("run-1", [snap], {token: changed})
    payload = B.verify_backup(path)
    assert payload["status"] == "READY"
    assert len(payload["assets"]) == 1
    assert payload["assets"][0]["key"]["library_reference"] == "Lib"
    assert payload["assets"][0]["original_tags"] == ["Old"]
    assert payload["assets"][0]["applied_tags"] == ["Old", "New"]
    assert payload["assets"][0]["fingerprint_before"]["sha256"] == "x"

    # 0 changed states -> valid but empty asset list.
    path0 = B.create_backup("run-0", [_snap("Zero", ["Old"])], {token: unchanged})
    assert B.verify_backup(path0)["assets"] == []

    # Tampering is rejected (checksum mismatch).
    raw = _read_json(path, {})
    raw["assets"][0]["original_tags"] = ["Tampered"]
    _write(path, raw)
    try:
        B.verify_backup(path)
        assert False, "tampered backup must be rejected"
    except RuntimeError:
        pass

    # Truncated / unreadable payload is rejected.
    _write(path, {})
    try:
        B.verify_backup(path)
        assert False, "empty backup payload must be rejected"
    except RuntimeError:
        pass

    # Missing checksum is rejected.
    _write(path, {"schema_version": 1, "status": "READY", "assets": []})
    try:
        B.verify_backup(path)
        assert False, "checksum-less backup must be rejected"
    except RuntimeError:
        pass

    # update_backup_states marks matching blend paths.
    p2 = B.create_backup("run-2", [_snap("Two", ["A"])], {_snap("Two", ["A"]).key.token: DesiredAssetState(key=_snap("Two", ["A"]).key, before=["A"], after=["A", "B"])})
    B.update_backup_states(p2, {"C:/lib/Two.blend"}, "APPLIED")
    state = B.verify_backup(p2)
    assert state["assets"][0]["restore_state"] == "APPLIED"

    # recoverable_backups ordering + prune always keeps the newest.
    B.delete_backup(p2)
    older = B.create_backup("run-old", [_snap("Old", ["x"])], {})
    # Windows st_mtime resolution can round two rapid writes to the same instant,
    # which would make the "newest is last" ordering assertion non-deterministic.
    # Enforce a real time separation so the ordering semantic is actually tested.
    time.sleep(0.05)
    newer = B.create_backup("run-new", [_snap("New", ["x"])], {})
    last = B.recoverable_backups()
    assert last and Path(last[-1]).name == Path(newer).name
    B.prune_backups(0)  # cutoff=now -> only the newest survives
    remaining = B.recoverable_backups()
    assert Path(newer).name in [Path(r).name for r in remaining]

    print("BACKUP TESTS OK")


main()
