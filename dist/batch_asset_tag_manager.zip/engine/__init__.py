"""BATM processing engines."""
