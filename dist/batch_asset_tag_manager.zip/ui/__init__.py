"""BATM user interface package."""
