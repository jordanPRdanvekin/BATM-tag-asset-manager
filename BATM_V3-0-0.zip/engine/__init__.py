"""BATM processing engines."""
