"""BATM user interface package."""
